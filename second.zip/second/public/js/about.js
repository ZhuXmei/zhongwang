/* 封装：向上滑入 20px */
function SlideUp(event){
    $(event).animate({marginTop:0,marginBottom:20},700);
}
$(function(){
    SlideUp("#tab1 .tab1_right>span");
    SlideUp("tab1_wh>.title_small");
    $("#tab1 .about>img").animate({top:0,opacity:1},700);
})

$(document).ready(function() {
    jQuery.jqtab = function(tabs,tabcon,defa) {
        $(tabcon).hide();//隐藏下面所有li
        $(tabs+' '+defa).addClass("thistab").show();//上面第一个li添加样式并显示
        $(tabcon+defa).show();// 下面第一个li显示
        
        $(tabs+" li").click(function() { //当点击上面li时，触发事件
          $(tabs+" li").removeClass("thistab");//隐藏默认显示的第一个的白色背景样式
          $(this).addClass("thistab");// 当前li添加白色背景样式
          $(tabcon).hide();//下边li隐藏
          var activeTab = $(this).find("a").attr("tab");//当前元素的子元素a标签的tab属性的值
          $("#"+activeTab).fadeIn();// #tab属性值 . 淡入显示下面li内容
          return false;
      });
  };
  /*调用*/
  $.jqtab("#tabs",".tab_con",".defa");  

  /* 动画效果 */
  $(window).scroll(function () {
        var d = $("#tab1").offset().top;
        if (d >= $(window).scrollTop() && d < ($(window).scrollTop() + $(window).height())) { 
            SlideUp("#tab1 .tab1_right>span")
            $("#tab1 .about>img").animate({top:0,opacity:1},700);
        }
        var e = $("#tab1").offset().top;
        if (e >= $(window).scrollTop() && e < ($(window).scrollTop() + $(window).height())) { 
            SlideUp("#tab1 .tab1_right>span")
            $("#tab1 .about>img").animate({top:0,opacity:1},700);
        }
    })
});

