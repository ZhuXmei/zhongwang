/* 功能一：头部引入 */
$(function(){
  
  $.ajax({
    url:"header.html",
    type:"get",
    success: function(res){
      $("<link rel='stylesheet' href='./css/header.css'>").appendTo("head");
      $(res).replaceAll("#header");
    }
  })
  $.ajax({
    url:"service.html",
    type:"get",
    success: function(res) {
      $(res).replaceAll("#service");
    }
  })
  $.ajax({
    url:"footer.html",
    type:"get",
    success: function(res) {
      $(res).replaceAll("#footer");
      $('button').click(function(e){
        e.preventDefault();
        var uname=$('#name').val();
        var phone=$('#phone').val();
        var info=$('#cont').val();

        console.log(uname,phone,info);
        $.ajax({
          url:'http://127.0.0.1:3000/info',
          type:"post",
          data:{uname,phone,info},
          success:function(result){
            console.log(result);
            if(result==1){
              alert("提交成功！");
              $('#name').val('')
              $('#phone').val('')
              $('#cont').val('');
            }
            else
              alert("提交失败！");
          }
        })
      })
    }
  })
  SlideUp("#tab1 .tab1_right>span");
  SlideUp(".tab1_wh>.title_small");
  SlideUp(".news .news_item");
  SlideUp("#tab1 .tab1_hj>");
  $("#tab1 .about>img").animate({top:0,opacity:1},700);
})

/* 封装：向上滑入 20px */
function SlideUp(event){
  $(event).animate({marginTop:0,marginBottom:20},700);
}



