$(function(){ 
    $(".service .i_content>p").animate({
        paddingTop:-120,
        opacity: 1
        },1500) 
    $(".service ul").addClass("parent");    
});

/* 导航随滚动条滚动显示隐藏 */
//判断鼠标滚轮滚动方向
if (window.addEventListener)//FF,火狐浏览器会识别该方法
    window.addEventListener('DOMMouseScroll', wheel, false);
window.onmousewheel = document.onmousewheel = wheel;//W3C
//统一处理滚轮滚动事件
function wheel(event){
    var delta = 0;
    if (!event) event = window.event;
    if (event.wheelDelta) {//IE、chrome浏览器使用的是wheelDelta，并且值为“正负120”
        delta = event.wheelDelta/120; 
        if (window.opera) delta = -delta;//因为IE、chrome等向下滚动是负值，FF是正值，为了处理一致性，在此取反处理
    } else if (event.detail) {//FF浏览器使用的是detail,其值为“正负3”
        delta = -event.detail/3;
    }
    if (delta)
        handle(delta);
}
//上下滚动时的具体处理函数
function handle(delta){
  var head=document.getElementById("header");
  if (delta <0){//向下滚动
    var num=parseInt(head.style.marginTop);
    var top=setInterval(function(){
      num-=5;
      if(num>-101){
        head.style.marginTop=num+"px";
      }else{clearInterval(top);}
    },10);
    head.style.marginTop="-100px";
  }else{//向上滚动
    var num=parseInt(head.style.marginTop);
    var top=setInterval(function(){
      num+=5;
      if(num<1){
          head.style.marginTop=num+"px";
      }else{clearInterval(top);}
    },10);
  }
}

// 动画效果
$(document).ready(function () {
    $(window).scroll(function () {
      /* 首页动画效果 */
      var a = $(".advantage .i_content>p").offset().top;
      if (a >= $(window).scrollTop() && a < ($(window).scrollTop() + $(window).height())) {
        $(".advantage .i_content>p").animate({
            paddingTop:-120,
            opacity: 1
        },1500) 
        $(".advantage>div>ul li").removeClass("transition");
        $(".advantage>div>ul li").addClass("adv_animate");
        $(".advantage>div>ul .adv").addClass("adv_div");            
        $(".advantage>div>ul img").addClass("adv_img");            
      }
      var b = $(".case .i_content>p").offset().top;   
      if (b >= $(window).scrollTop() && b < ($(window).scrollTop() + $(window).height())) {
        $(".case .i_content>p").animate({
            paddingTop:-120,
            opacity: 1
            },1500) 
        $(".case ul").addClass("parent");
      }
      var c = $(".about .i_content>p").offset().top;
      if (c >= $(window).scrollTop() && c < ($(window).scrollTop() + $(window).height())) {
        $(".about .i_content>p").animate({
            paddingTop:-120,
            opacity: 1
        },1500) 
        $(".about>div>div").animate({top:0},1000) 
      }
      var c = $(".news_content").offset().top;
      if (c >= $(window).scrollTop() && c < ($(window).scrollTop() + $(window).height())) {
        $(".news_content").animate({
            top:25,
        },1000) 
      }
    });
  })
