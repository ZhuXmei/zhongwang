$(function(){ 
  $(".case .i_content>p").animate({
    paddingTop:-120,
    opacity: 1
    },1500) 
  $(".case ul").addClass("parent");
  function anima(a){
    $(a).animate({
    paddingTop:-120,
    opacity: 1
    },1500) 
    $(b).addClass("parent");
  }
  anima('.ourservice','.ourservice')
})