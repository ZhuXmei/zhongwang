SET NAMES UTF8;
DROP DATABASE IF EXISTS onlineinfo;
CREATE DATABASE onlineinfo CHARSET=UTF8;
USE onlineinfo;
/*用户表*/
CREATE TABLE info(
    uid INT PRIMARY KEY AUTO_INCREMENT,
    uname VARCHAR(32),
    phone VARCHAR(16),
    content VARCHAR(255)
)
