//创建mysql连接池
const mysql = require('mysql');
var pool = mysql.createPool({
  host:'127.0.0.1',
  user:'root',
  password:'',
  database:'onlineinfo',
  connectionLimiit:10
});
//导出
module.exports = pool;