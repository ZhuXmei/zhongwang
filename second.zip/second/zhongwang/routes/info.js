const express=require("express");
//引入连接池对象
const pool=require("../pool");
//创建一个空的路由
const router=express.Router();
//用户登录
router.post('/',(req,res)=>{
  var obj=req.body;
  var $uname=obj.uname;
  var $phone=obj.phone;
  var $info=obj.info;
  console.log(obj);
  if(!$uname){
    res.send({code:401,msg:'uname required'});
    console.log(123)
    return;
  }
  if(!$phone){
    res.send({code:402,msg:'upwd required'});
    return;
  }
  if(!$info){
    res.send({code:403,msg:'info required'});
    return;
  }
  var sql='INSERT INTO info VALUES(null,?,?,?)';
  pool.query(sql,[$uname,$phone,$info],(err,result)=>{
    if(err) throw err;
    if(result.affectedRows > 0)
      res.send("1")
    else
      res.send("2")
  })
})

module.exports=router;